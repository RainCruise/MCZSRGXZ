package mqclient.mqclient;

/**
 * Created by 潮俊 on 2016/10/20.
 */

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.igexin.sdk.PushConsts;
import com.igexin.sdk.PushManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import cn.jpush.android.api.JPushInterface;

public class GetuiPushReceiver extends BroadcastReceiver {

    /**
     * 应用未启动, 个推 service已经被唤醒,保存在该时间段内离线消息(此时 GetuiSdkDemoActivity.tLogView == null)
     */
    public static StringBuilder payloadData = new StringBuilder();
    public static String address = LoginActivity.address + "/state";
    public static String uuid = "";
    public static int notificationID = 0;
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        Log.d("GetuiSdkDemo", "onReceive() action=" + bundle.getInt("action"));

        if (JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())) {
        }else if (JPushInterface.ACTION_MESSAGE_RECEIVED.equals(intent.getAction())) {
          //  System.out.println("收到了自定义消息。消息内容是：" + bundle.getString(JPushInterface.EXTRA_MESSAGE));
            // 自定义消息不会展示在通知栏，完全要开发者写代码去处理
            JSONObject jsonObject1 = new JSONObject();
            try{
                jsonObject1.accumulate("uuid",uuid);
                jsonObject1.accumulate("id",LoginActivity.id);
                jsonObject1.accumulate("category","Android");
                jsonObject1.accumulate("from","JiGuang");
                jsonObject1.accumulate("JiGuangToken",LoginActivity.jToken );
                jsonObject1.accumulate("state","RECEIVED");
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

           // String state = uuid + " " + LoginActivity.id + " Android 极光 " + LoginActivity.jToken + "RECEIVED";
            SendMessage sendState = new SendMessage(address,jsonObject1.toString());
            sendState.start();

            String content = bundle.getString(JPushInterface.EXTRA_MESSAGE);
            String extra = bundle.getString(JPushInterface.EXTRA_EXTRA);

            System.out.println("收到了自定义消息@@消息内容是:"+ content);
            //System.out.println("收到了自定义消息@@消息extra是:"+ extra);
            //Map<String, Object> map = new HashMap<String, Object>();
            String title = "",content1 = "";
            JSONObject jsonObject;
            try {
                jsonObject = new JSONObject(content);
                uuid = jsonObject.getString("uuid");
                //map.put("uuid", uuid);
                title = jsonObject.getString("title");
                content1 = jsonObject.getString("content");
               // map.put("title",title);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            //title = bundle.getString(JPushInterface.EXTRA_TITLE);
           // map.put("content", content);

            NotificationCompat.Builder mBuilder =
                    new NotificationCompat.Builder(context)
                            .setSmallIcon(R.drawable.push)
                            .setContentTitle(title)
                            .setContentText(content1);

            Intent resultIntent = new Intent(context, LoginActivity.class);
            resultIntent.putExtra("fromNotification","JiGuang");
            resultIntent.putExtra("uuid",uuid);
            TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
            stackBuilder.addParentStack( LoginActivity.class);
            stackBuilder.addNextIntent(resultIntent);
            PendingIntent resultPendingIntent =
                    stackBuilder.getPendingIntent(
                            0,
                            PendingIntent.FLAG_UPDATE_CURRENT
                    );
            mBuilder.setContentIntent(resultPendingIntent);
            NotificationManager mNotificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.notify(notificationID, mBuilder.build());
            ++notificationID;


            JSONObject jsonObject2 = new JSONObject();
            try{
                jsonObject2.accumulate("uuid",uuid);
                jsonObject2.accumulate("id",LoginActivity.id);
                jsonObject2.accumulate("category","Android");
                jsonObject2.accumulate("from","JiGuang");
                jsonObject2.accumulate("JiGuangToken",LoginActivity.jToken );
                jsonObject2.accumulate("state","SHOWED");
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
           // String state1 = uuid + " " + LoginActivity.id + " Android 极光 " + LoginActivity.jToken + "SHOWED";
            SendMessage sendState1 = new SendMessage(address,jsonObject2.toString());
            sendState1.start();
        } else if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent.getAction())) {
            System.out.println("收到了通知");
            // 在这里可以做些统计，或者做些其他工作

        } else if (JPushInterface.ACTION_NOTIFICATION_OPENED.equals(intent.getAction())) {
            System.out.println("用户点击打开了通知");
            // 在这里可以自己写代码去定义用户点击后的行为
           // Intent i = new Intent(context, TestActivity.class);  //自定义打开的界面
            //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           // context.startActivity(i);

        } else {
           // Log.d(TAG, "Unhandled intent - " + intent.getAction());
            if(JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())){

                LoginActivity.jToken = bundle.getString(JPushInterface.EXTRA_REGISTRATION_ID);
                System.out.println("jToken:" + LoginActivity.jToken);
            }
        }
        switch (bundle.getInt(PushConsts.CMD_ACTION)) {
            case PushConsts.GET_MSG_DATA:
                // 获取透传数据
                // String appid = bundle.getString("appid");
                JSONObject jsonObject1 = new JSONObject();
                try{
                    jsonObject1.accumulate("uuid",uuid);
                    jsonObject1.accumulate("id",LoginActivity.id);
                    jsonObject1.accumulate("category","Android");
                    jsonObject1.accumulate("from","GeTui");
                    jsonObject1.accumulate("GeTuiToken",LoginActivity.gToken );
                    jsonObject1.accumulate("state","RECEIVED");
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //String state = uuid + " " + LoginActivity.id + " Android 个推 " + LoginActivity.gToken + "RECEIVED";
                SendMessage sendState = new SendMessage(address,jsonObject1.toString());
                sendState.start();

                byte[] payload = bundle.getByteArray("payload");

                String taskid = bundle.getString("taskid");
                String messageid = bundle.getString("messageid");

                // smartPush第三方回执调用接口，actionid范围为90000-90999，可根据业务场景执行
                boolean result = PushManager.getInstance().sendFeedbackMessage(context, taskid, messageid, 90002);
                System.out.println("第三方回执接口调用" + (result ? "成功" : "失败"));
                String data = new String(payload);
                if (payload != null) {


                    Log.d("GetuiSdkDemo", "receiver payload : " + data);

                    payloadData.append(data);
                    payloadData.append("\n");
                   // System.out.print(payloadData);
                    //if (GetuiSdkDemoActivity.tLogView != null) {
                      //  GetuiSdkDemoActivity.tLogView.append(data + "\n");
                    //}
                }
                String title = "",content = "";

                // map.put("content", content);
                JSONObject jsonObject;
                try {
                    jsonObject = new JSONObject(data);

                    uuid = jsonObject.getString("uuid");
                    System.out.println("uuid:" + uuid);
                    //map.put("uuid", uuid);
                    title = jsonObject.getString("title");
                    System.out.println("title:" + title);
                    content = jsonObject.getString("content");
                    System.out.println("content:" + content);
                    // map.put("title",title);
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                NotificationCompat.Builder mBuilder =
                        new NotificationCompat.Builder(context)
                                .setSmallIcon(R.drawable.push)
                                .setContentTitle(title)
                                .setContentText(content);
                Intent resultIntent = new Intent(context, LoginActivity.class);
                resultIntent.putExtra("fromNotification","GeTui");
                resultIntent.putExtra("uuid",uuid);
                TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
                stackBuilder.addParentStack( LoginActivity.class);
                stackBuilder.addNextIntent(resultIntent);
                PendingIntent resultPendingIntent =
                        stackBuilder.getPendingIntent(
                                0,
                                PendingIntent.FLAG_UPDATE_CURRENT
                        );
                mBuilder.setContentIntent(resultPendingIntent);
                NotificationManager mNotificationManager =
                        (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.notify(notificationID, mBuilder.build());
                ++notificationID;

                JSONObject jsonObject2 = new JSONObject();
                try{
                    jsonObject2.accumulate("uuid",uuid);
                    jsonObject2.accumulate("id",LoginActivity.id);
                    jsonObject2.accumulate("category","Android");
                    jsonObject2.accumulate("from","GeTui");
                    jsonObject2.accumulate("GeTuiToken",LoginActivity.gToken );
                    jsonObject2.accumulate("state","SHOWED");
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //state = uuid + " " + LoginActivity.id + " Android 个推 " + LoginActivity.gToken + "SHOWED";
                SendMessage sendState1 = new SendMessage(address,jsonObject2.toString());
                sendState1.start();


                break;

            case PushConsts.GET_CLIENTID:
                // 获取ClientID(CID)
                // 第三方应用需要将CID上传到第三方服务器，并且将当前用户帐号和CID进行关联，以便日后通过用户帐号查找CID进行消息推送
                String cid = bundle.getString("clientid");
                System.out.println("cid:" + cid);
                LoginActivity.gToken = cid;
               // if (GetuiSdkDemoActivity.tView != null) {
               //     GetuiSdkDemoActivity.tView.setText(cid);
                //}
                break;
            case PushConsts.GET_SDKONLINESTATE:
                boolean online = bundle.getBoolean("onlineState");
                Log.d("GetuiSdkDemo", "online = " + online);
                break;

            case PushConsts.SET_TAG_RESULT:
                String sn = bundle.getString("sn");
                String code = bundle.getString("code");

                String text = "设置标签失败, 未知异常";
                switch (Integer.valueOf(code)) {
                    case PushConsts.SETTAG_SUCCESS:
                        text = "设置标签成功";
                        break;

                    case PushConsts.SETTAG_ERROR_COUNT:
                        text = "设置标签失败, tag数量过大, 最大不能超过200个";
                        break;

                    case PushConsts.SETTAG_ERROR_FREQUENCY:
                        text = "设置标签失败, 频率过快, 两次间隔应大于1s";
                        break;

                    case PushConsts.SETTAG_ERROR_REPEAT:
                        text = "设置标签失败, 标签重复";
                        break;

                    case PushConsts.SETTAG_ERROR_UNBIND:
                        text = "设置标签失败, 服务未初始化成功";
                        break;

                    case PushConsts.SETTAG_ERROR_EXCEPTION:
                        text = "设置标签失败, 未知异常";
                        break;

                    case PushConsts.SETTAG_ERROR_NULL:
                        text = "设置标签失败, tag 为空";
                        break;

                    case PushConsts.SETTAG_NOTONLINE:
                        text = "还未登陆成功";
                        break;

                    case PushConsts.SETTAG_IN_BLACKLIST:
                        text = "该应用已经在黑名单中,请联系售后支持!";
                        break;

                    case PushConsts.SETTAG_NUM_EXCEED:
                        text = "已存 tag 超过限制";
                        break;

                    default:
                        break;
                }

                Log.d("GetuiSdkDemo", "settag result sn = " + sn + ", code = " + code);
                Log.d("GetuiSdkDemo", "settag result sn = " + text);
                break;
            case PushConsts.THIRDPART_FEEDBACK:


                String appid = bundle.getString("appid");
                String taskid1 = bundle.getString("taskid");
                String actionid = bundle.getString("actionid");
                String result1 = bundle.getString("result");
                long timestamp = bundle.getLong("timestamp");
                Log.d("GetuiSdkDemo", "appid = " + appid);
                Log.d("GetuiSdkDemo", "taskid = " + taskid1);
                Log.d("GetuiSdkDemo", "actionid = " + actionid);
                Log.d("GetuiSdkDemo", "result = " + result1);
                Log.d("GetuiSdkDemo", "timestamp = " + timestamp);

                break;

            default:
                break;
        }

    }
}
