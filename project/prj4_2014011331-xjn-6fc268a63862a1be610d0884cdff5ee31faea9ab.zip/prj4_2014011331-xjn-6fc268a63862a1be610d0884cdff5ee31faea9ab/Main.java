package demo;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.gexin.rp.sdk.base.IPushResult; 
import com.gexin.rp.sdk.base.impl.AppMessage; 
import com.gexin.rp.sdk.http.IGtPush; 
import com.gexin.rp.sdk.template.LinkTemplate;
import java.io.IOException; 
import java.util.ArrayList; 
import java.util.List;
public class Main extends JFrame implements ActionListener{
    //ਧԎଉᰁ, appId̵appKey̵masterSecret ᯻አ๜෈໩ "ᒫԫྍ  "ᦤڂᳯᦢݐ឴ Ӿ឴஑ጱଫአᯈᗝ    
		private static String appId = "5el9EpL0DI79ekTHZEAhj2";    
		private static String appKey = "1W9gaMmfiW5HEvbkVmalv7";    
		private static String masterSecret = "3oPOGNYMJ87LxpePNsB0j5";    
		private static String url = "http://sdk.open.api.igexin.com/apiex.htm";
		String name="name",passwd="password";
	    int row=2,col=26;
	    JButton	dialog = new JButton("普通推送");
	    JTextArea ta = new JTextArea("推送记录:", row, col);
	    //JButton exit = new JButton("退出");
	   
	    Main()
	    {
	       setTitle("demo");
	       this.setLayout(new BorderLayout());
	       this.add("North",dialog);
	       this.add("Center",ta);
	       JScrollPane jsp1 = new JScrollPane(ta);
	       jsp1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	       jsp1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	       this.add(jsp1);
	       this.setSize(500,400);
	       //
	       //this.add(exit);
	       //exit.addActionListener(this);
	       dialog.addActionListener(this);
	       setVisible(true);
	       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	    }
	   
	    public void actionPerformed(ActionEvent e)
	    {	
	    	MyDialog dlg = new MyDialog(this,true);
	        dlg.show();
	    }
	   
	    public static void main (String[] args) throws IOException
	    {
	       Main a=new Main();
	    }
	   
	    class MyDialog extends Dialog implements ActionListener
	    {
	       JLabel label1 = new JLabel("title");
	       JLabel label2 = new JLabel("message");
	       JTextField names = new JTextField(50);
	       JTextField passwds = new JTextField(50);
	       JButton ok = new JButton("ok");
	       //JButton cancel = new JButton("取消");
	       MyDialog(Main parent, boolean modal)
	       {
	           super(parent,modal);
	           setTitle("推送内容");
	           setSize(260,100);
	           setResizable(false);
	           JPanel p1=new JPanel();
	           setLayout(new BorderLayout());
	           p1.setLayout(new GridLayout(2,2));
	           p1.add(label1);
	           p1.add(names);
	           p1.add(label2);
	           p1.add(passwds);
	           add(p1,"Center");
	           add(ok,"South");
	           //add(cancel);
	           ok.setBounds(600, 100, 60, 25);
	           //cancel.setBounds(140, 100, 60, 25);
	           ok.addActionListener(this);
	           //cancel.addActionListener(this);
	       }
	      
	       public void actionPerformed(ActionEvent e)
	       {
	           if (e.getSource()==ok)
	           {
	              name = names.getText();
	              passwd = passwds.getText();
	              row+=2;
	              ta.setRows(row);
	              ta.setColumns(col);
	              ta.setText(ta.getText()+"\n"+"title:" + name + "\nmessage:" + passwd);
	              try{
	              sentMessage(name,passwd);
	              }catch(Exception ee)
	              {
	            	  ee.printStackTrace();
	              }
	           }
	           dispose();
	       }
	       public void sentMessage(String title,String mes) throws IOException {
	           IGtPush push = new IGtPush(url, appKey, masterSecret);
	           // ਧԎ" "຃ཛྷᎣ᭗୏಑ള᱾ڋᅩ ҅ଚᦡᗝຽ̵ٖ᷌਻̵᱾ള       
	           LinkTemplate template = new LinkTemplate();        
	           template.setAppId(appId);        
	           template.setAppkey(appKey);        
	           template.setTitle(title);        
	           template.setText(mes);        
	           template.setUrl("http://getui.com");
	           List<String> appIds = new ArrayList<String>();        
	           appIds.add(appId);
	           // ਧԎ"AppMessage"ຽፓጱᭆݎ̵຃ཛྷ਻ٖ௳ၾᗝᦡ҅᨝੒௳ၾࣳᔄApp 
	           AppMessage message = new AppMessage();        
	           message.setData(template);        
	           message.setAppIdList(appIds);        
	           message.setOffline(true);        
	           message.setOfflineExpireTime(1000 * 600);
	           IPushResult ret = push.pushMessageToApp(message);        
	           row+=1;
	           ta.setRows(row);
	           ta.setText(ta.getText()+"\n"+ret.getResponse().toString());
	           //System.out.println(ret.getResponse().toString());    
	       } 
	    }
		//public static void main(String[] args) throws IOException {
		//	sentMessage();
		//}
		
		public static void sentMessage(String title,String mes) throws IOException {
        IGtPush push = new IGtPush(url, appKey, masterSecret);
        // ਧԎ" "຃ཛྷᎣ᭗୏಑ള᱾ڋᅩ ҅ଚᦡᗝຽ̵ٖ᷌਻̵᱾ള       
        LinkTemplate template = new LinkTemplate();        
        template.setAppId(appId);        
        template.setAppkey(appKey);        
        template.setTitle(title);        
        template.setText(mes);        
        template.setUrl("http://getui.com");
        List<String> appIds = new ArrayList<String>();        
        appIds.add(appId);
        // ਧԎ"AppMessage"ຽፓጱᭆݎ̵຃ཛྷ਻ٖ௳ၾᗝᦡ҅᨝੒௳ၾࣳᔄApp 
        AppMessage message = new AppMessage();        
        message.setData(template);        
        message.setAppIdList(appIds);        
        message.setOffline(true);        
        message.setOfflineExpireTime(1000 * 600);
        IPushResult ret = push.pushMessageToApp(message);        
        System.out.println(ret.getResponse().toString());    
    } 
	    }
