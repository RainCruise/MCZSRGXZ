package Worker;

import java.net.InetAddress;


import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.QueueingConsumer;

import net.sf.json.JSONObject;
import platform.GeTui;

public class WorkerGeTui {
	
	private final static String QUEUE_NAME = "celery";
	
    public static void main(String[] args) throws Exception {

        String localHost1 = InetAddress.getLocalHost().getHostAddress();
        System.out.println(localHost1);
        ConnectionFactory factory = new ConnectionFactory();
        
        String localHost = InetAddress.getLocalHost().getHostAddress();
        System.out.println(localHost);
        
        factory.setHost("101.5.218.32");
        factory.setUsername("admin");
        factory.setPassword("admin");
        factory.setPort(AMQP.PROTOCOL.PORT);
        
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        
        boolean durable = true; 
        channel.queueDeclare(QUEUE_NAME, durable, false, false, null);
        QueueingConsumer consumer = new QueueingConsumer(channel);
         
        boolean ack = false ;
        channel.basicConsume(QUEUE_NAME, ack, consumer);
        
        int prefetchCount = 1;
        channel.basicQos(prefetchCount);
        
        while (true)
        {
            QueueingConsumer.Delivery delivery = consumer.nextDelivery();
            
            String message = new String(delivery.getBody());
            String []content = message.split("//");
            
            JSONObject jsonObject = new JSONObject();
            try {
            	jsonObject.put("uuid", content[3]);
            	jsonObject.put("title", content[4]);
            	jsonObject.put("content", content[5]);
			} catch (Exception e) {
				e.printStackTrace();
			}
            
            String contents = jsonObject.toString();
            
            String userId = content[1];
            System.out.println(userId);
            
            String appId = "jfKdsvxh2f8HDHPzESbK4A";
    		String masterSecret = "WQNCCOYsdf9isFRP2U2ik8";
    		String appKey = "Om2OnPv0rt5FqSxXoQjvD1";
    		String cliendId = "7c8ab58a904d8925fc160fd28b31534c";
    		
            GeTui geTui = new GeTui(appId, appKey, masterSecret);
            geTui.send(contents, cliendId);
            System.out.println(contents);
            
            channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
            System.out.println("Received Done");
        }
    }
}
