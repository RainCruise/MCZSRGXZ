from django.apps import AppConfig


class SendMessageConfig(AppConfig):
    name = 'send_message'
