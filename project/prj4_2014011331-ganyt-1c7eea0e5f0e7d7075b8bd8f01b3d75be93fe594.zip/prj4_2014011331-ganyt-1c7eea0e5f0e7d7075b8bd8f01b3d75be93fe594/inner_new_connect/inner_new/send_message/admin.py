from django.contrib import admin
from .models import Message,SendMessageUser,Statistic,UserDevice

# Register your models here.
class MessageAdmin(admin.ModelAdmin):
    list_display = ('uuid', 'title')

class UserAdmin(admin.ModelAdmin):
    list_display = ('username', )

class UserDeviceAdmin(admin.ModelAdmin):
    list_display = ('user_id', )

class StatisticAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'status',)
    
admin.site.register(Message, MessageAdmin)
admin.site.register(SendMessageUser, UserAdmin)
admin.site.register(Statistic, StatisticAdmin)
admin.site.register(UserDevice, UserDeviceAdmin)
