package com.server.rabbitmq;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

import MySQL.TokenGet;
import net.sf.json.JSONObject;
import MySQL.Ack;
import platform.GeTui;
import platform.JiGuang;

public class App 
{
	private final static String QUEUE_NAME = "celery";
	private static ConnectionFactory factory;
	private static String host = null;
	
    public static void main(String[] args) {
    	
        String ip1 = "10.0.0.9";
        String ip2 = "10.0.0.8";
        String ip3 = "10.0.0.7";
        int i = 1;
        while (i<11){
        	host = null;
        	if(canConnect(ip1)){
            	host = ip1;
            }
            else if(canConnect(ip2)){
            	host = ip2;
            }
            else if(canConnect(ip3)){
            	host = ip3;
            }
            else{
            	System.out.println("[X] " +i + " failed to connect...");
            	i++;
            }
            if(host != null){
            	i=1;
            	work();
            }
        }
    }
    
    public static boolean canConnect(String IP)
    {
    	int timeOut = 3000;
    	boolean status = false;
        if(IP!=null){
        	try {
				status = InetAddress.getByName(IP).isReachable(timeOut);
				return status;
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
        return false;
    }
    
    public static void work()
    {
		try {
			factory = new ConnectionFactory();
	    	factory.setHost(host);
	        factory.setUsername("admin");
	        factory.setPassword("admin");
	        factory.setPort(AMQP.PROTOCOL.PORT);
	        
	        System.out.println("Listening...");
	        
	        Connection connection;
			connection = factory.newConnection();
			Channel channel = connection.createChannel();
	        
	        boolean durable = true; 
	        channel.queueDeclare(QUEUE_NAME, durable, false, false, null);
	        QueueingConsumer consumer = new QueueingConsumer(channel);
	        
	        boolean ack = false ;
	        channel.basicConsume(QUEUE_NAME, ack, consumer);
	        
	        int prefetchCount = 100;
	        channel.basicQos(prefetchCount);
	        
	        while (true)
	        {
	            QueueingConsumer.Delivery delivery = consumer.nextDelivery();
	            
	            String message = new String(delivery.getBody());
	            
	            channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
	            String []content = message.split("//");
	            
	            JSONObject jsonObject = new JSONObject();
	            jsonObject.put("uuid", content[3]);
	            jsonObject.put("title", content[4]);
	            jsonObject.put("content", content[5]);
	            
	            String contents = jsonObject.toString();
	            
	            String userId = content[1];
	            String platform = content[2];
	            String uuid = content[3];
	            String title = content[4];

	            if (platform.equals("JiGuang") ){
	            	
	            	String masterSecret = "d0c5b0c365cb1207f72460c9";
	        		String appKey = "b3e4119aab26203b96c103b6";
	        		String temp =TokenGet.getToken(userId, "jiguang");
	        				//"120c83f7602d849247f";
	        		if(temp != null && !temp.equals("")){
	        			String[] registrationID = temp.split(";");
	        			JiGuang jiGuang = new JiGuang(masterSecret, appKey);
		                for (int i = 1; i < registrationID.length; i++){
	                		jiGuang.send(title, contents, registrationID[i]);
		                	Ack.AckToMySQL(uuid, registrationID[i], userId, "jiguang");
		                }
	        		}
	        		
	            }
	            
	            else if (platform.equals("GeTui")){
	            	
	            	String appId = "jfKdsvxh2f8HDHPzESbK4A";
	        		String masterSecret = "WQNCCOYsdf9isFRP2U2ik8";
	        		String appKey = "Om2OnPv0rt5FqSxXoQjvD1";
	        		
	        		String temp = TokenGet.getToken(userId, "getui");
	        		if (temp != null && !temp.equals("")){
	        			String []cliendId = temp.split(";");
	        			GeTui geTui = new GeTui(appId, appKey, masterSecret);
		                for (int i=1; i < cliendId.length; i++){
		                		geTui.send(contents, cliendId[i]);	
			                	Ack.AckToMySQL(uuid, cliendId[i], userId, "getui");
		                }
	        		}
	        				//"7c8ab58a904d8925fc160fd28b31534c";
	            }
	        }
	        
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (TimeoutException e1) {
			e1.printStackTrace();
		} catch (ShutdownSignalException e1) {
			e1.printStackTrace();
		} catch (ConsumerCancelledException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		} catch (NullPointerException e1) {
			e1.printStackTrace();
		}
		System.out.println("Stop Listening...");
    }
}
