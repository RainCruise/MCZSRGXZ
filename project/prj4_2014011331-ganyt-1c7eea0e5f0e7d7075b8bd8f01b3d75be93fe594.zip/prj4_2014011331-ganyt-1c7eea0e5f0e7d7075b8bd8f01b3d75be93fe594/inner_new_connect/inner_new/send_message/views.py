﻿#coding:utf-8
from django.shortcuts import render, render_to_response
from django.http import HttpResponseRedirect, HttpResponse
from send_message.models import SendMessageUser, Message, Statistic, UserDevice
from django import forms
import re
import datetime
from send_message.task import send
from django.utils import timezone
# Create your views here.

def send_message(request):
    b = str(request.POST)
    mode = re.compile(r"\'.*?\'")
    strs = mode.findall(b)
    if strs is not None:
        if strs:
            mode = re.compile(r"/PLATFORM:.*?\:PLATFORM/")
            r = mode.findall(strs[1])[0]
            platform = r[10:-10]

            mode = re.compile(r"/TITLE:.*?\:TITLE/")
            r = mode.findall(strs[1])[0]
            title = r[7:-7]

            mode = re.compile(r"/CONTENTS:.*?\:CONTENTS/")
            r = mode.findall(strs[1])[0]
            contents = r[10:-10]

            mode = re.compile(r"/FILE:.*?\:FILE/")
            r = mode.findall(strs[1])[0]
            usermessage = r[6:-6]

            mode = re.compile(r"/UUID:.*?\:UUID/")
            r = mode.findall(str(strs[1]))[0]
            uuid = r[6:-6]
            title_contents = "//" + platform +"//" + uuid + "//" + title + "//" + contents + "//"
            user_message = usermessage.split("\\r\\n")
            tempnum = 0;
            for i in range(user_message.__len__()):
                tempnum += 1;
                tempstr = "//" + user_message[i] + title_contents
                send.delay(tempstr)
            Message.objects.create(uuid=uuid, title=title, content=contents, users=user_message, time=timezone.now(), params="", send_number=tempnum, show_number=0, click_number=0, receive_number=0)
    return render(request, 'send_message/send_message.html')

def about(request):
    return render(request, 'send_message/about.html')
def history(request):
    uuid_message = str(request.GET)
    mode = re.compile(r"\'.*?\'")
    r = mode.findall(uuid_message)
    if r:
        result = eval(r[1])
        exist = Message.objects.filter(m_id=result)
        if exist:
            b_con = Message.objects.get(m_id=result).content
            b_title = Message.objects.get(m_id=result).title
            b_users = Message.objects.get(m_id=result).users
            b_time = str(Message.objects.get(m_id=result).time)
            b_send_num = str(Message.objects.get(m_id=result).send_number)
            b_show_num = str(Message.objects.get(m_id=result).show_number)
            b_click_num = str(Message.objects.get(m_id=result).click_number)
            b_receive_num = str(Message.objects.get(m_id=result).receive_number)
            hr = b_con+"//"+b_title+"//"+b_users+"//"+b_time+"//"+b_send_num+"//"+b_show_num+"//"+b_click_num+"//"+b_receive_num
            return HttpResponse(hr)
        else:
            return HttpResponse("NotFind//s")
    return render(request, 'send_message/history.html')

#定义表单模型
class UserForm(forms.Form):
    username = forms.CharField(label='UserName ', max_length=100)
    password = forms.CharField(label='PassWord ', widget=forms.PasswordInput())

def login(request):
    if request.method == 'POST':
        # 获取表单用户密码
        a_username = str(request.POST['username'])
        a_password = str(request.POST['password'])
        # 获取的表单数据与数据库进行比较
        user = SendMessageUser.objects.filter(username__exact=a_username, password__exact=a_password)
        if user:
            return HttpResponseRedirect('/send_message.html/')
        else:
            return HttpResponseRedirect('/')
    return render_to_response('send_message/login.html')

#注册
def register(request):
    if request.method == 'POST':
        uf = UserForm(request.POST)
        if uf.is_valid():
            #获得表单数据
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            #添加到数据库
            SendMessageUser.objects.create(username=username, password=password)
            return HttpResponseRedirect('../')
    else:
        uf = UserForm()
    return render_to_response('send_message/register.html', {'uf': uf})
