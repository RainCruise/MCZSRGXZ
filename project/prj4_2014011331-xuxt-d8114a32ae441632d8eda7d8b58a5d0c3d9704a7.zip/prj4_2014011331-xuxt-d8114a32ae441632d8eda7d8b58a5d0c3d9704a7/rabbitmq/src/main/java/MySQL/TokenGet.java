package MySQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class TokenGet {
	private static Connection connection;
	private static String driver = "com.mysql.jdbc.Driver";
	//10.0.0.22
	private static String url = "jdbc:mysql://10.0.0.22:3306/mc";
	private static String user = "root";
	private static String password = "Mczsrgxz_1234";
	public static String getToken (String userID, String platform) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			if(!connection.isClosed()){
				Statement statement = connection.createStatement();
				String SQL = "select device_token_"+platform+" from user_device where user_id="+userID;
				ResultSet resultSet = statement.executeQuery(SQL);
				String clientID = "";
				while(resultSet.next()){
					clientID= clientID + ";" + resultSet.getString("device_token_"+platform);
				}
				System.out.println(clientID);
				resultSet.close();
				connection.close();
				return clientID;
			}
		} catch (ClassNotFoundException e) {
			System.out.println("驱动没有找到...");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("连接失败...");
			e.printStackTrace();
		}
		return null;
	}
	
}
