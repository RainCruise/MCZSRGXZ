package platform;

import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.TransmissionTemplate;

public class GeTui {
    private IGtPush push = null;
    private String appId = null;
    private String appKey = null;
    private String clientId = null;
    private String content = null;
    private static String url = "http://sdk.open.api.igexin.com/apiex.htm";
    
    public GeTui(String appId, String appKey, String masterSecret){
    	this.appId = appId;
    	this.appKey = appKey;
    	
    	push = new IGtPush(url, appKey, masterSecret);
    }
    
    public boolean send(String transmissionContent, String clientIdTemp){
    	this.content = transmissionContent;
    	this.clientId = clientIdTemp;
    	boolean ok = false;
    	TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(appId);
        template.setAppkey(appKey);
        template.setTransmissionType(1);
        template.setTransmissionContent(content);
        
        SingleMessage message = new SingleMessage();
        message.setData(template);
        message.setOffline(true);
        message.setOfflineExpireTime(1000 * 600);
        
        Target target = new Target();
        target.setAppId(appId);
        target.setClientId(clientId);
        IPushResult ret = push.pushMessageToSingle(message, target);
        ok = ret.getResponse().containsValue("ok");
        System.out.println(ret.getResponse().toString());
        System.out.println(ok);
        return ok;
    }
}
