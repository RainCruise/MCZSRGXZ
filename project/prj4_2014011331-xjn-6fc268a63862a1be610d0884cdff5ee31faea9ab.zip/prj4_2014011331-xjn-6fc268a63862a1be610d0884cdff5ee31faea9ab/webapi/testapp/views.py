#codig:utf-8
from django.http import HttpResponse
from django.shortcuts import render
from testapp.models import User
from testapp.models import UserDevice
from testapp.models import Statistic
from testapp.models import Message
from django.views.decorators.csrf import csrf_exempt
import json
import urllib2
from django.core import serializers


# Create your views here.

def index(request):
	return HttpResponse(u"success!")

@csrf_exempt
def login(request):
    if request.method == 'POST':
        s = json.loads(request.body)
	user_name = s["id"]
	pass_word = s["password"]
	jiguang_token = s["JiGuangToken"]
	getui_token = s["GeTuiToken"]
	if len(User.objects.filter(name=user_name,password=pass_word)) == 0:
		if len(User.objects.filter(name=user_name)) == 0:#new user
			p = User(name=user_name, password=pass_word)
			p.save()
			if len(UserDevice.objects.filter(device_token_getui=getui_token,device_token_jiguang=jiguang_token)) == 0:#new device
				d = UserDevice(user_id=user_name,device_token_getui=getui_token,device_token_jiguang=jiguang_token)
				d.save()
			else:#update user
				for obj in UserDevice.objects.filter(device_token_getui=getui_token,device_token_jiguang=jiguang_token):
					obj.user_id=user_name
					obj.save()
			return HttpResponse("true")
		else:#wrong password
			return HttpResponse("false")
	else:
		return HttpResponse("true")
	return HttpResponse("invalid")
    else:
	return HttpResponse("invalid")

@csrf_exempt
def token(request):
    if request.method == 'POST':
        s = json.loads(request.body)
	print(request.body)
	user_name = s["id"]
	jiguang_token = s["JiGuangToken"]
	getui_token = s["GeTuiToken"]
	if len(UserDevice.objects.filter(device_token_getui=getui_token,device_token_jiguang=jiguang_token)) == 0:#new device
		d = UserDevice(user_id=user_name,device_token_getui=getui_token,device_token_jiguang=jiguang_token)
		d.save()
	else:#update user
		for obj in UserDevice.objects.filter(device_token_getui=getui_token,device_token_jiguang=jiguang_token):
			obj.user_id=user_name
			obj.save()
    	return HttpResponse("success")
    else:
	return HttpResponse("invalid")


@csrf_exempt
def state(request):
    if request.method == 'POST':
        s = json.loads(request.body)
	user_name = s["id"]
	u_uid = s["uuid"]
	fr = s["from"]
	st = s["state"]
	mess = Message.objects.get(uuid=u_uid)
	if len(UserDevice.objects.filter(device_token_getui=token)) == 0:
		return HttpResponse("invalid")
	if fr == "GeTui":
		token = s["GeTuiToken"]
		if len(UserDevice.objects.filter(device_token_getui=token)) > 0:
			for obj in Statistic.objects.filter(device_id=token,uuid=u_uid):
				if st == "RECEIVED" and (st == "sent"):
					obj.status = st
					mess.receive_number = mess.receive_number + 1;
				if st == "SHOWED" and (st == "sent" or st == "RECEIVED"):
					obj.status = st
					mess.show_number = mess.show_number + 1;	
				if st == "CLICKED" and (st == "sent" or st == "RECEIVED" or st == "SHOWED"):
					obj.status = st
					mess.click_number = mess.click_number + 1;
				obj.save()
				mess.save()
			return HttpResponse("true")
	if fr == "JiGuang":
		token = s["JiGuangToken"]
		if len(UserDevice.objects.filter(device_token_jiguang=token)) > 0:
			for obj in Statistic.objects.filter(device_id=token,uuid=u_uid):
				if st == "RECEIVED" and (st == "sent"):
					obj.status = st
					mess.receive_number = mess.receive_number + 1;
				if st == "SHOWED" and (st == "sent" or st == "RECEIVED"):
					obj.status = st
					mess.show_number = mess.show_number + 1;	
				if st == "CLICKED" and (st == "sent" or st == "RECEIVED" or st == "SHOWED"):
					obj.status = st
					mess.click_number = mess.click_number + 1;
				obj.save()
				mess.save()
			return HttpResponse("true")
	return HttpResponse("invalid")
    else:
	return HttpResponse("invalid")

