package MySQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Ack {
	private static Connection connection;
	private static String driver = "com.mysql.jdbc.Driver";
	//10.0.0.22
	private static String url = "jdbc:mysql://10.0.0.22:3306/mc";
	private static String user = "root";
	private static String password = "Mczsrgxz_1234";
	public static boolean AckToMySQL (String uuid, String token, String userID, String platform) {
		boolean ok = false;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			if(!connection.isClosed()){
				String SQL1 = "insert into statistic(uuid,device_id,user_id,channel,status) values(?,?,?,?,?)";	
				String SQL2 = "update message set send_number=send_number+1 where uuid=" + "\""+uuid+"\"";
				PreparedStatement preparedStatement = connection.prepareStatement(SQL1);
				preparedStatement.setString(1, uuid);
				preparedStatement.setString(2, token);
				preparedStatement.setString(3, userID);
				preparedStatement.setString(4, platform);
				preparedStatement.setString(5, "sent");
				preparedStatement.executeUpdate();
				PreparedStatement preparedStatement2 = connection.prepareStatement(SQL2);
				preparedStatement2.executeUpdate();
				connection.close();
				return ok;
				
			}
		} catch (ClassNotFoundException e) {
			System.out.println("驱动没有找到...");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("连接失败...");
			e.printStackTrace();
		}
		return ok;
	}
}
