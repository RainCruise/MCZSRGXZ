package Worker;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.QueueingConsumer;

import net.sf.json.JSONObject;
import platform.JiGuang;

public class WorkerJiGuang {
	
	private final static String QUEUE_NAME = "celery";
	
    public static void worker() throws Exception {
    	
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("101.5.124.46");
        factory.setUsername("admin");
        factory.setPassword("admin");
        factory.setPort(AMQP.PROTOCOL.PORT);
        
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        
        boolean durable = true; 
        channel.queueDeclare(QUEUE_NAME, durable, false, false, null);
        QueueingConsumer consumer = new QueueingConsumer(channel);
         
        boolean ack = false ;
        channel.basicConsume(QUEUE_NAME, ack, consumer);
        
        int prefetchCount = 1;
        channel.basicQos(prefetchCount);
        
        while (true)
        {
            QueueingConsumer.Delivery delivery = consumer.nextDelivery();
            
            String message = new String(delivery.getBody());
            String []content = message.split("//");
            
            JSONObject jsonObject = new JSONObject();
            try {
            	jsonObject.put("uuid", content[2]);
            	jsonObject.put("title", content[3]);
            	jsonObject.put("content", content[4]);
			} catch (Exception e) {
				e.printStackTrace();
			}
            
            String title = content[3];
            String contents = jsonObject.toString();
            
            String userId = content[1];
            System.out.println(userId);
            
    		String masterSecret = "d0c5b0c365cb1207f72460c9";
    		String appKey = "b3e4119aab26203b96c103b6";
    		String registrationID = "120c83f7602d849247f";
    		
            JiGuang jiGuang = new JiGuang(masterSecret, appKey);
            jiGuang.send(title, contents, registrationID);
            System.out.println(contents);
            
            channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
            System.out.println("Received Done");

        }
    }
}
