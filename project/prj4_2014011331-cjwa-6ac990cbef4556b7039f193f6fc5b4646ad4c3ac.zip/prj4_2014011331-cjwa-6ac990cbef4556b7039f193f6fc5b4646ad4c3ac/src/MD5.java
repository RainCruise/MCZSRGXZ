package mqclient.mqclient;

/**
 * Created by 潮俊 on 2016/10/30.
 */
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 * 对外提供getMD5(String)方法
 * @author randyjia
 *
 */
public class MD5 {

    public static String getMD5(String val) throws NoSuchAlgorithmException{
        StringBuffer sb = new StringBuffer();
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        md5.update(val.getBytes());
        for (byte b : md5.digest()) {
            sb.append(String.format("%02X", b)); // 10进制转16进制，X 表示以十六进制形式输出，02 表示不足两位前面补0输出
        }
        System.out.println(sb.toString());
        return sb.toString();
    }
}
