package platform;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.push.PushResult;

public class JiGuang {
	public JPushClient jPushClient = null;
	private String title = null;
	private String content = null;
	private String registrationID = null;

	public JiGuang(String masterSecret, String appKey){
		jPushClient = new JPushClient(masterSecret, appKey);
	}
	
	public boolean send(String titleTemp, String contentTemp, String registrationIDTemp) {
		boolean ok = false;
		this.content = contentTemp;
		this.title = titleTemp;
		this.registrationID = registrationIDTemp;
		try {
			PushResult pushResult = jPushClient.sendAndroidMessageWithRegistrationID(title, content, registrationID);			
			ok = pushResult.isResultOK();
			System.out.println(pushResult.toString());
			System.out.println(ok);
			return ok;
		} catch (APIConnectionException e) {
			System.out.println("Connection error.");
			e.printStackTrace();
        	System.out.println("Should retry later.");
		} catch (APIRequestException e) {
			System.out.println("Error response from JPush server.");
			e.printStackTrace();
        	System.out.println("Should review and fix it.");
		}
		return ok;
	}
}