package mqclient.mqclient;

import android.content.Context;

/**
 * Created by 潮俊 on 2016/10/20.
 */
public class ContextHolder {
    static Context ApplicationContext;
    public static void initial(Context context) {
        ApplicationContext = context;
    }
    public static Context getContext() {
        return ApplicationContext;
    }
}
